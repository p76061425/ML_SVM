# Chinese Sign Language Gesture Dataset

This archive contains the data used in the study:  
Tse-Yu Pan, Li-Yun Lo, Chung-Wei Yeh, Jhe-Wei Li, 
Hou-Tim Liu, and Min-Chun Hu, 
Real-time Sign Language Recognition in Complex Background Scene 
Based on a Hierarchical Clustering Classification Method  
**Please reference the article if you use this data!**


### The rule of name
Alphbets + No  
* Alphbets
  -  a to z

Example : b105.jpg

### Content
Each image has been preprocessed by hand segmentation from the 
complex background scene.   

